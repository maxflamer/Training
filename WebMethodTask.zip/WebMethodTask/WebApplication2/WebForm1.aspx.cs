﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Services;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Http.Cors;
using System.Activities.Statements;

namespace WebApplication2
{
    public partial class WebForm1 : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        //kc
        //[WebMethod]
        //public static string Get_details(string arg1)
        //{

        //    return "hai:" + arg1;
        //}



        //teja
        //[ScriptMethod]
        //[WebMethod]
        //public static string CallingWebService(string strParam)
        //{
        //    return "dharani " + strParam;
        //}


        
        [WebMethod]
        [ScriptMethod]
        public static string Function(string arg1, string arg2)
        {
            return arg1 + " " + arg2;
        }
    }
}
