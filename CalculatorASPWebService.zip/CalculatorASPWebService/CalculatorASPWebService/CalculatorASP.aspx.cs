﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CalculatorASPWebService
{
    public partial class CalculatorASP : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            labelresult.Text = "";
        }

        protected void buttonadd_Click(object sender, EventArgs e)
        {
            int number1 = int.Parse(textboxfirstnumber.Text);
            int number2 = int.Parse(textboxsecondnumber.Text);
            ServiceReference1.WebService1SoapClient myService = new ServiceReference1.WebService1SoapClient();
            double result = myService.Addition(number1, number2);
            labelresult.Text = result.ToString();
        }

        protected void buttonsubtract_Click(object sender, EventArgs e)
        {
            int number1 = int.Parse(textboxfirstnumber.Text);
            int number2 = int.Parse(textboxsecondnumber.Text);
            ServiceReference1.WebService1SoapClient myService = new ServiceReference1.WebService1SoapClient();
            double result = myService.Subtraction(number1, number2);
            labelresult.Text = result.ToString();
        }

        protected void buttonmultiply_Click(object sender, EventArgs e)
        {
            int number1 = int.Parse(textboxfirstnumber.Text);
            int number2 = int.Parse(textboxsecondnumber.Text);
            ServiceReference1.WebService1SoapClient myService = new ServiceReference1.WebService1SoapClient();
            double result = myService.Multiplication(number1, number2);
            labelresult.Text = result.ToString();
        }

        protected void buttondivide_Click(object sender, EventArgs e)
        {
            int number1 = int.Parse(textboxfirstnumber.Text);
            int number2 = int.Parse(textboxsecondnumber.Text);
            ServiceReference1.WebService1SoapClient myService = new ServiceReference1.WebService1SoapClient();
            double result = myService.Division(number1, number2);
            labelresult.Text = result.ToString();
        }

       
    }
}