﻿using System;

using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.Serialization;

namespace CompanyDetailsXML
{
    public partial class Dashboard : System.Web.UI.Page
    {
        

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["TraineesConnection"].ConnectionString);
                SqlCommand GetDetails = new SqlCommand("SELECT ID,Name,Address,EmployeeDetails FROM Company_Details", connection);

                SqlDataAdapter adapter = new SqlDataAdapter(GetDetails);
                DataTable datatable = new DataTable();
                adapter.Fill(datatable);

                string CompanyName = string.Empty;
                string CompanyAddress = string.Empty;
                string EmployeeDetails = string.Empty;

                if (datatable.Rows.Count == 0)
                {
                    button_AddCompany.Visible = true;
                }
                else
                {
                    button_AddCompany.Visible = false;

                    foreach (DataRow row in datatable.Rows)
                    {
                        EmployeeDetails = row["EmployeeDetails"].ToString();
                        CompanyName = row["CompanyName"].ToString();
                        CompanyAddress = row["CompanyAddress"].ToString();

                    }

                    var doc = new XmlDocument();
                    doc.LoadXml(EmployeeDetails);

                    XmlSerializer deserializer = new XmlSerializer(typeof(List<Employee>));

                    
                    
                    

                    label_CompanyName.Text = CompanyName;
                    label_CompanyAddress.Text = CompanyAddress;

                    gridview_CompanyDetails.DataSource = datatable;
                    gridview_CompanyDetails.DataBind();
                }

            
            }

            
        }

        protected void button_AddCompany_Click(object sender, EventArgs e)
        {
            Response.Redirect("CompanyDetails.aspx");
        }
    }
}