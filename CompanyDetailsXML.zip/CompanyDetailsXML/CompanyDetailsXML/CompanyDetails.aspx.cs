﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CompanyDetailsXML
{
    public partial class CompanyDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void button_Next_Click(object sender, EventArgs e)
        {
            Session["CompanyID"] = textbox_CompanyID.Text;
            Session["CompanyName"] = textbox_CompanyName.Text;
            Session["CompanyAddress"] = textbox_CompanyAddress.Text;



            Response.Redirect("EmployeeDetails.aspx");
        }
    }
}