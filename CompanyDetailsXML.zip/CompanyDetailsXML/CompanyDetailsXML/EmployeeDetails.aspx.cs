﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.Serialization;

namespace CompanyDetailsXML
{
    [XmlRoot]
    public class Employee
    {
        public string ID { get; set; }
        public string Name { get; set; }
        public string Department { get; set; }
        public string Salary { get; set; }
    }

    public partial class EmployeeDetails : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["CompanyID"] != null)
                label_CompanyID.Text = Session["CompanyID"].ToString();

            if (Session["CompanyName"] != null)
                label_CompanyName.Text = Session["CompanyName"].ToString();

            if (!IsPostBack)
            {
                if (HttpContext.Current.Cache["EmployeeList"] != null)
                {
                    List<Employee> employeeList = new List<Employee>();
                    employeeList = (List<Employee>)HttpContext.Current.Cache["EmployeeList"];

                    gridview_Employees.DataSource = employeeList;
                    gridview_Employees.DataBind();
                }

            }
        }

        protected void button_AddEmployee_Click(object sender, EventArgs e)
        {

            int record_exists = 0;

            List<Employee> employeeList = new List<Employee>();

            if (HttpContext.Current.Cache["EmployeeList"] != null)
              employeeList = (List<Employee>)HttpContext.Current.Cache["EmployeeList"];

                Employee employee = new Employee();
            employee.ID = textbox_EmployeeID.Text;
            employee.Name = textbox_EmployeeName.Text;
            employee.Department = textbox_EmployeeDepartment.Text;
            employee.Salary = textbox_EmployeeSalary.Text;

            foreach (var item in employeeList)
            {
                if (item.ID == textbox_EmployeeID.Text || item.Name == textbox_EmployeeName.Text)
                {
                    record_exists = 1;
                }
            }

            if (record_exists == 0)
                employeeList.Add(employee);

            else
                label_Message.Text = "Record already exists";

            
            HttpContext.Current.Cache.Insert("EmployeeList", employeeList, null, DateTime.Now.AddMinutes(20), System.Web.Caching.Cache.NoSlidingExpiration);

            gridview_Employees.DataSource = employeeList;
            gridview_Employees.DataBind();

            textbox_EmployeeID.Text = "";
            textbox_EmployeeName.Text = "";
            textbox_EmployeeDepartment.Text = "";
            textbox_EmployeeSalary.Text = "";

        }

        protected void button_Save_Click(object sender, EventArgs e)
        {
            List<Employee> employeeList = new List<Employee>();

            if (HttpContext.Current.Cache["EmployeeList"] != null)
                employeeList = (List<Employee>)HttpContext.Current.Cache["EmployeeList"];

            XmlSerializer xmlserialiser = new XmlSerializer(typeof(List<Employee>));


            var xml = "";

            using (var stringwriter = new StringWriter())
            {
                using (XmlWriter writer = XmlWriter.Create(stringwriter))
                {
                    xmlserialiser.Serialize(writer, employeeList);
                    xml = stringwriter.ToString(); // Your XML


                    XmlDocument xd = new XmlDocument();
                    xd.LoadXml(xml);
                    xml = xd.DocumentElement.InnerXml;
                }
            }


            SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["TraineesConnection"].ConnectionString);
            SqlCommand SaveDetails = new SqlCommand("INSERT INTO Company_Details(ID,Name,Address,EmployeeDetails) VALUES (@Id,@Name,@Address,@EmployeeDetails) ", connection);
            SaveDetails.Parameters.AddWithValue("@Id", SqlDbType.VarChar).Value = Session["CompanyID"].ToString();
            SaveDetails.Parameters.AddWithValue("@Name", SqlDbType.VarChar).Value = Session["CompanyName"].ToString();
            SaveDetails.Parameters.AddWithValue("@Address", SqlDbType.VarChar).Value = Session["CompanyAddress"].ToString();
            SaveDetails.Parameters.AddWithValue("@EmployeeDetails", SqlDbType.Xml).Value = xml;

            connection.Open();
            int added_row = SaveDetails.ExecuteNonQuery();
            connection.Close();
            if (added_row == 1)
            {
                textbox_EmployeeID.Text = "";
                textbox_EmployeeName.Text = "";
                textbox_EmployeeDepartment.Text = "";
                textbox_EmployeeSalary.Text = "";

                label_Message.Text = "Added successfully";
            }
            else
            {
                label_Message.Text = "Could not add the company";
            }

        }

        protected void label_ViewDetails_Click(object sender, EventArgs e)
        {
            
            Response.Redirect("Dashboard.aspx");
        }
    }
}