﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace GridView
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void button_Click(object sender, EventArgs e)
        {

           //var list = new List<name>();
           var textboxName = (this.textboxName.Text);
            var textboxAge = int.Parse(this.textboxAge.Text);
            var textboxDept = (this.textboxDept.Text);
            //list.Add(new name("Me",21,"ECE"));
            //list.Add(new name("You", 30, "CSE"));
            //list.Add(new name("He", 11, "EEE"));
            //list.Add(new name("She", 23, "BME"));
            //list.Add(new name(textboxName,textboxAge,textboxDept));
            ServiceReference1.WebService1SoapClient myService = new ServiceReference1.WebService1SoapClient();
            myService.send_data(textboxName, textboxAge, textboxDept);
            DataSet ds = myService.get_data();
            GridView1.DataSource = ds;
            GridView1.DataBind();



            //GridView1.DataSource = list;
            GridView1.DataBind();
        }
    }
    //public class name
    //{
    //    public string NAME { get; set; }
    //    public int AGE { get; set; }
    //    public string DEPT { get; set; }

    //    public name() { }

    //    public name(string a, int b, string c)
    //    {
    //        this.NAME = a;
    //        this.AGE = b;
    //        this.DEPT = c;
    //    }
    //}
}