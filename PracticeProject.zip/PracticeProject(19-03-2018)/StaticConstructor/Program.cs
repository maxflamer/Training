﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticConstructor
{
    class Program
    {
        public class SomeClass
        {
            public SomeClass()
            {
                Console.WriteLine("Normal constructor called");
            }

            static SomeClass()
            {
                Console.WriteLine("Static constructor called");
            }
        }

        static void Main(string[] args)
        {
            SomeClass random = new SomeClass();

            //  Static constructors automatically invokes before normal constructors can be used to initialise fields
        }
    }
}
