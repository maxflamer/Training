﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Convertion
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = "20";
            int i = Convert.ToInt32(s);

            Console.WriteLine(i);

            int j = 3453;
            string t = Convert.ToString(j);

            Console.WriteLine(t);
        }
    }
}
