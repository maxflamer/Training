﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeProject
{
    class AbstractClass
    {
        public abstract class Abstract
        {
            public abstract void Hello();

            public virtual void Hi()
            {
                Console.WriteLine("Hi");
            }
        }

        public class Bear : Abstract
        {
            public override void Hello()
            {
                Console.WriteLine("I'm a bear");
            }

        }

        
            //  Instantiation not allowed
            //Abstract a = new Abstract();

            
        
    }
}
