﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static PracticeProject.AbstractClass;

namespace PracticeProject
{
    class Program
    {

        public static void BoxingUnboxing()
        {
            int i = 1;
            object o = i; // boxing

            Console.WriteLine(o);


            int j = (int)o; // unboxing

            Console.WriteLine(j);
        }

        public static void Casting()
        {
            float f = 2.9090909090909090900909090090909090f;
            int m = (int)f;

            Console.WriteLine(m);


            int n = 2;
            float g = (float)n;

            Console.WriteLine(g);

            //string s = "2";
            //int k = (int)s; //error

            float h = 4.40494040400303030202f;
            double d = (float)h;

            Console.WriteLine(d);

            //double c = 1.222929030434904093929393956747;
            //float p = (double)c; //error
        }

        public static void Conversion()
        {
            string s = "20";
            int integer = Convert.ToInt32(s);

            Console.WriteLine(integer);

            int number = 3453;
            string t = Convert.ToString(number);

            Console.WriteLine(t);
        }

        static void Main(string[] args)
        {

            //  Boxing and unboxing
            BoxingUnboxing();

            

            //  Casting
            Casting();



            //  Conversion
            Conversion();



            //  Abstract class 
            Bear b = new Bear();
            b.Hello();



            //  Partial class
            PartialClass.Student s1 = new PartialClass.Student();
            s1.Name();



            //  Sealed class
            SealedClass s = new SealedClass();



            //  Static class
            StaticClass.Print();


            
            //  Default constructor
            DefaultConstructor d = new DefaultConstructor();
            DefaultConstructor.Student student = new DefaultConstructor.Student();
            Console.WriteLine(student.i);
            Console.WriteLine(student.hello);
            Console.WriteLine(student.letter);
            //Default constructor initialises int to 0, string to "" and char to ''



            //  Parameterised constructor
            ParameterisedConstructor p = new ParameterisedConstructor();
            ParameterisedConstructor.Student stu1 = new ParameterisedConstructor.Student(1, "Me", 'A');
            ParameterisedConstructor.Student stu2 = new ParameterisedConstructor.Student(2, "You", 'F');
            
            Console.WriteLine(stu1.id);
            Console.WriteLine(stu1.name);
            Console.WriteLine(stu1.grade);

            Console.WriteLine("");

            Console.WriteLine(stu2.id);
            Console.WriteLine(stu2.name);
            Console.WriteLine(stu2.grade);

            //Parameterised constructor used for initialising objects with different values passed as parameters



            //  Copy constructor
            CopyConstructor.Student stud1 = new CopyConstructor.Student(1, "Me", 'B');
            CopyConstructor.Student stud2 = new CopyConstructor.Student(stud1);

            Console.WriteLine(stud1.id);
            Console.WriteLine(stud1.name);
            Console.WriteLine(stud1.grade);

            Console.WriteLine("");

            Console.WriteLine(stud2.id);
            Console.WriteLine(stud2.name);
            Console.WriteLine(stud2.grade);

            //  Copy Constructors copies value of passed object into current object



            //  Private constructor
            //PrivateConstructor.Sample privat = new PrivateConstructor.Sample();
            //  Private class restricts instantiation

            Console.WriteLine(PrivateConstructor.Sample.value);



            //  Static constructor
            StaticConstructor random = new StaticConstructor();
        }
    }
}
