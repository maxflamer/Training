﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeProject
{
    public static class StaticClass
    {
        public static int i { get; set; }

        static StaticClass()
        {
            i = 20;
        }

        public static void Print()
        {
            Console.WriteLine(i);
        }

    }
}
