﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeProject
{
    class PrivateConstructor
    {
        public class Sample
        {
            private Sample()
            {

            }

            public static int value { get; set; }
        }
    }
}
