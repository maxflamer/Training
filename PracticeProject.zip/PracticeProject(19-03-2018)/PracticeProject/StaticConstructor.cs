﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeProject
{
    public class StaticConstructor
    {
        public StaticConstructor()
        {
            Console.WriteLine("Normal constructor called");
        }

        static StaticConstructor()
        {
            Console.WriteLine("Static constructor called");
        }
    }
}
