﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeProject
{
    public class DefaultConstructor
    {
        public class Student
        {
            public int i { get; set; }
            public string hello { get; set; }
            public char letter { get; set; }

            public Student()
            {

            }
        }
    }
}
