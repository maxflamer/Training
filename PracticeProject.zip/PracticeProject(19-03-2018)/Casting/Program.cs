﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Casting
{
    class Program
    {
        static void Main(string[] args)
        {
            float f = 2.9090909090909090900909090090909090f;
            int i = (int)f;

            Console.WriteLine(i);


            int j = 2;
            float g = (float)i;

            Console.WriteLine(g);

            //string s = "2";
            //int k = (int)s; //error

            float h = 4.40494040400303030202f;
            double d = (float)h;

            Console.WriteLine(d);

            //double c = 1.222929030434904093929393956747;
            //float p = (double)c; //error

        }
    }
}
