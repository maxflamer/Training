﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyConstructor
{
    class Program
    {
        public class Student
        {
            public int id { get; set; }
            public string name { get; set; }
            public char grade { get; set; }

            public Student(int ID, string Name, char Grade)
            {
                id = ID;
                name = Name;
                grade = Grade;
            }

            //  Copy Constructor
            public Student(Student student)
            {
                id = student.id;
                name = student.name;
                grade = student.grade;
            }
        }

        static void Main(string[] args)
        {
            Student s1 = new Student(1, "Me", 'B');
            Student s2 = new Student(s1);

            Console.WriteLine(s1.id);
            Console.WriteLine(s1.name);
            Console.WriteLine(s1.grade);

            Console.WriteLine("");

            Console.WriteLine(s2.id);
            Console.WriteLine(s2.name);
            Console.WriteLine(s2.grade);

            //  Copy Constructors copies value of passed object into current object
        }
    }
}
