﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrivateConstructor
{
    class Program
    {
        public class Sample
        {
            private Sample()
            {

            }

            public static int value { get; set; }
        }

        static void Main(string[] args)
        {
            //  Private class restricts instantiation
            //Sample s = new Sample();

            Console.WriteLine(Sample.value);
            
        }
    }
}
