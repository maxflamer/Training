﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SealedClass
{
    class Program
    {
        public sealed class Sealed
        {
            public Sealed()
            {
                Console.WriteLine("I'm a seal");
            }
        }


        //  Error
        //public class Demo : Sealed
        //{
            
        //}

        static void Main(string[] args)
        {
            Sealed s = new Sealed();
        }
    }
}
