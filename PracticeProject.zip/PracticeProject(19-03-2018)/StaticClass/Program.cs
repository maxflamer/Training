﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticClass
{
    class Program
    {
        public static class Static
        {
            public static int i { get; set; }

            static Static()
            {
                i = 20;
            }

            public static void Print()
            {
                Console.WriteLine(i);
            }
        }

        static void Main(string[] args)
        {
            Static.Print();
        }
    }
}
