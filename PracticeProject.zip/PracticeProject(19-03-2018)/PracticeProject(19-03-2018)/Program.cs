﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeProject_19_03_2018_
{
    class Program
    {
        public class Student
        {
            public int i { get; set; }
            public string hello { get; set; }
            public char letter { get; set; }

            public Student()
            {

            }
        }

        static void Main(string[] args)
        {
            Student student = new Student();
            Console.WriteLine(student.i);
            Console.WriteLine(student.hello);
            Console.WriteLine(student.letter);
            //Default constructor initialises int to 0, string to "" and char to ''
        }
    }
}
