﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartialClass
{
    class Program
    {
        public partial class Student
        {
            public Student()
            {
                Console.WriteLine("I am a student");
            }
        }

        public partial class Student
        {
            public void Name()
            {
                Console.WriteLine("My name is Vegeta");
            }
        }

        static void Main(string[] args)
        {
            
        }
    }
}
