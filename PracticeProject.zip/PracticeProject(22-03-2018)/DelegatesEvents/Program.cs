﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesEvents
{
    
    class Program
    {
        


        static void Main(string[] args)
        {
            //  Multi-cast
            dele del = new dele(Delegates.Add);

            del += Delegates.Subtract;

            del += Delegates.Multiply;

            del += Delegates.Divide;

            del(10, 5);


            //  Array of delegates
            del[] dele = { new del(Delegates.Write), new del(Delegates.Draw), new del(Delegates.Print) };

            //for (int i = 0; i < dele.Length; i++)
            //{
            //    dele[i]("Rabbit");
            //    dele[i]("Mouse");
            //    dele[i]("Cat");
            //}

            foreach (var item in dele)
            {
                item("Rabbit");
            }


            //  Enums
            Console.WriteLine(Enums.Gender.female);
            Console.WriteLine(Enums.Gender.male);
            Console.WriteLine(Enums.Gender.unknown);
                    
        }
    }
}
