﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesEvents
{
    public class Enums
    {
        public enum Gender
        {
            male = 10, female = 15, unknown = 20
        }
    }
}
