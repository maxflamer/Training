﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesEvents
{
    public delegate void dele(int a, int b);

    public delegate void del(string s);

    public static class Delegates
    {
        public static void Add(int a, int b)
        {
            Console.WriteLine(a + b);
        }

        public static void Subtract(int a, int b)
        {
            Console.WriteLine(a - b);
        }

        public static void Multiply(int a, int b)
        {
            Console.WriteLine(a * b);
        }

        public static void Divide(int a, int b)
        {
            Console.WriteLine(a / b);
        }

        public static void Write(string s)
        {
            Console.WriteLine(s);
        }

        public static void Print(string s)
        {
            Console.WriteLine(s);
        }

        public static void Draw(string s)
        {
            Console.WriteLine(s);
        }
    }
}
