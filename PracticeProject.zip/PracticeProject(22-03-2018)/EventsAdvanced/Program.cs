﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventsAdvanced
{
    public delegate void EventHandler(string a);

    public class EventHandlingClass
    {
        public event EventHandler eventHandler;

        public void Action(string a)
        {
            if (eventHandler != null)
            {
                eventHandler(a);
                Console.WriteLine(a);
            }
            else
            {
                Console.WriteLine("Not Registered");
            }
        }
    }

    class Program
    {

        public static void CatchEvent(string s)
        {
            Console.WriteLine("Method Calling");
        }


        static void Main(string[] args)
        {
            EventHandlingClass e = new EventHandlingClass();

            e.Action("Event Calling");
            e.eventHandler += new EventHandler(CatchEvent);
            e.Action("Registered");

        }
    }
}
