﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOverloading
{
    class Program
    {
        public class Add
        {
            public void Addition(int a, int b)
            {
                Console.WriteLine(a+b);
            }

            public void Addition(float a, float b)
            {
                Console.WriteLine(a + b);
            }

            public void Addition(string a, string b)
            {
                Console.WriteLine(a + b);
            }

            public void Addition(char a, char b)
            {
                Console.WriteLine(a + b);
            }

        }

        static void Main(string[] args)
        {
            Add a = new Add();

            a.Addition(3, 6);

            a.Addition(2.2f, 4.4f);

            a.Addition("What's ", "up?");

            a.Addition('a', 'b');
        }
    }
}
