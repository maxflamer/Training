﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOverriding
{
    class Program
    {
        public class Father
        {
            public virtual void Intro()
            {
                Console.WriteLine("I like news");
            }
        }

        public class Son : Father
        {
            public override void Intro()
            {
                //base.Intro();
                Console.WriteLine("I like cartoons");
            }
        }

        static void Main(string[] args)
        {
            Son s = new Son();
            s.Intro();
        }
    }
}
