﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeProject
{
    class MethodOverloading
    {
        public class Add
        {
            public void Addition(int a, int b)
            {
                Console.WriteLine(a + b);
            }

            public void Addition(float a, float b)
            {
                Console.WriteLine(a + b);
            }

            public void Addition(string a, string b)
            {
                Console.WriteLine(a + b);
            }

            public void Addition(char a, char b)
            {
                Console.WriteLine(a + b);
            }

        }
    }
}
