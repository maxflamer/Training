﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeProject
{
    class MethodHiding
    {
        public class Stark
        {
            public void Say()
            {
                Console.WriteLine("Winter");
            }
        }

        public class Ned : Stark
        {
            public new void Say()
            {
                Console.WriteLine("Winter is coming");
            }
        }
    }
}
