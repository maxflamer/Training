﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeProject
{
    class Program
    {
        static void Main(string[] args)
        {
            //  Inheritence
            Inheritence.Manners m = new Inheritence.Manners();
            m.Hello();
            m.Greeting();



            //  Method hiding
            MethodHiding.Stark s = new MethodHiding.Stark();
            s.Say();

            //  Hiding the parents functionality with a new one

            MethodHiding.Ned n = new MethodHiding.Ned();
            n.Say();

            MethodHiding.Stark S = new MethodHiding.Ned();
            S.Say();



            //  Method Overloading
            MethodOverloading.Add a = new MethodOverloading.Add();

            a.Addition(3, 6);

            a.Addition(2.2f, 4.4f);

            a.Addition("What's ", "up?");

            a.Addition('a', 'b');



            //  Method Overriding
            MethodOverriding.Son son = new MethodOverriding.Son();
            son.Intro();
        }
    }
}
