﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeProject
{
    class MethodOverriding
    {
        public class Father
        {
            public virtual void Intro()
            {
                Console.WriteLine("I like news");
            }
        }

        public class Son : Father
        {
            public override void Intro()
            {
                //base.Intro();
                Console.WriteLine("I like cartoons");
            }
        }
    }
}
