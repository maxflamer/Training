﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticeProject
{
    class Inheritence
    {
        public interface Interface1
        {
            void Hello();
        }

        public class A : Interface1
        {
            void Interface1.Hello()
            {
                Console.WriteLine("Hello");
            }
        }


        public interface Interface2
        {
            void Greeting();
        }

        public class B : Interface2
        {
            public void Greeting()
            {
                Console.WriteLine("How are you?");
            }
        }


        public class Manners : Interface1, Interface2
        {
            A a = new A();
            B b = new B();

            public void Greeting()
            {
                ((Interface2)b).Greeting();
            }

            public void Hello()
            {
                ((Interface1)a).Hello();
            }
        }
    }
}
