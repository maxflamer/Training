﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodHiding
{
    class Program
    {
        public class Stark
        {
            public void Say()
            {
                Console.WriteLine("Winter");
            }
        }

        public class Ned : Stark
        {
            public new void Say()
            {
                Console.WriteLine("Winter is coming");
            }
        }

        static void Main(string[] args)
        {
            Stark s = new Stark();
            s.Say();

            //  Hiding the parents functionality with a new one

            Ned n = new Ned();
            n.Say();

            Stark S = new Ned();
            S.Say();
        }
    }
}
