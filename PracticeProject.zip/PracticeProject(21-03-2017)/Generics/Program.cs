﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generics
{
    class Program
    {
        public class GenericClass<t>
        {
            public GenericClass(t type)
            {
                Console.WriteLine(type);
            }
        }

        public static void GenericMethod<t>(t type)
        {
            Console.WriteLine(type);
        }

        static void Main(string[] args)
        {
            GenericClass<int> integer = new GenericClass<int>(5);

            GenericClass<string> str = new GenericClass<string>("Ball");

            GenericClass<char> character = new GenericClass<char>('S');

            GenericClass<float> floatingpoint = new GenericClass<float>(2.4325324f);


            GenericMethod(4);

        }
    }
}
