﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HashSet
{
    class Program
    {
        static void Main(string[] args)
        {
            HashSet<string> hash = new HashSet<string>();
            hash.Add("Hello");
            hash.Add("Hello");
            hash.Add("Hi");

            foreach (var item in hash)
            {
                Console.WriteLine(item);
            }
        }
    }
}
