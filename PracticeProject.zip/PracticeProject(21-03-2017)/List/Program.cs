﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace List
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> list = new List<string>();
            list.Add("ABC");
            list.Add("DEF");
            list.Add("GHI");
            list.Add("JKL");
            list.Add("MNO");
            list.Remove("MNO");

            foreach (var item in list)
            {
                Console.WriteLine(item);
            }

        }
    }
}
