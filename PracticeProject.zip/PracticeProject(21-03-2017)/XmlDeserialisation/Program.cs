﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.IO;

namespace XmlDeserialisation
{
    public class Program
    {
        
        public class Address
        {
            public string City { get; set; }
            public int HouseNo { get; set; }
            public string StreetName { get; set; }
        }

        [XmlRoot("Root")]
        public class PersonalDetails
        {
            [XmlElement("Name")]
            public string Name { get; set; }

            [XmlElement("Age")]
            public int Age { get; set; }

            [XmlElement("address")]
            public Address address = new Address();

            public PersonalDetails()
            {

            }

            public void SetAddress(Address a)
            {
                address.City = a.City;
                address.HouseNo = a.HouseNo;
                address.StreetName = a.StreetName;
            }

        }

        static void Main(string[] args)
        {
            XmlSerializer deserializer = new XmlSerializer(typeof(PersonalDetails));
            TextReader reader = new StreamReader(@"U:\SerialisingExample.txt");
            object obj = deserializer.Deserialize(reader);
            PersonalDetails XmlData = (PersonalDetails)obj;
            reader.Close();

        }
    }
}
