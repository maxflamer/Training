﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortedSet
{
    class Program
    {
        static void Main(string[] args)
        {

            SortedSet<string> sorted = new SortedSet<string>();
            sorted.Add("Saitama");
            sorted.Add("Kratos");
            sorted.Add("Clark");
            
            foreach (var item in sorted)
            {
                Console.WriteLine(item);
            }
        }
    }
}
