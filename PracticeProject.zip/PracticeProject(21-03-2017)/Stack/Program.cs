﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Stack
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack<string> stack = new Stack<string>();
            stack.Push("Bruce");
            stack.Push("Arthur");
            stack.Push("Barry");

            Console.WriteLine(stack.Pop());
            Console.WriteLine(stack.Peek());
        }
    }
}
