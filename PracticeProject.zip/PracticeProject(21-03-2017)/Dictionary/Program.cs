﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dictionary
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int, string> dictionary = new Dictionary<int, string>();
            dictionary.Add(1, "Hola");
            dictionary.Add(2, "Bonjour");
            dictionary.Add(3, "Hallo");
            dictionary.Add(4, "Ciao");

            dictionary.Remove(4);

            foreach (KeyValuePair<int,string> item in dictionary)
            {
                Console.WriteLine(item);
            }
        }
    }
}
