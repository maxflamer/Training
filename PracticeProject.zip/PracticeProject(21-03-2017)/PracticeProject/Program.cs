﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;


namespace PracticeProject
{
    public class Program
    {

        public class Students
        {

            public int ID { get; set; }
            public string Name { get; set; }
            public char Grade { get; set; }
        }

        public class Address
        {
            public string City { get; set; }
            public int HouseNo { get; set; }
            public string StreetName { get; set; }
        }

        public class PersonalDetails
        {
            public string Name { get; set; }
            public int Age { get; set; }
            public Address address = new Address();

            public PersonalDetails()
            {

            }

            public void SetAddress(Address a)
            {
                address.City = a.City;
                address.HouseNo = a.HouseNo;
                address.StreetName = a.StreetName;
            }

        }




        public class GenericClass<t>
        {
            public GenericClass(t type)
            {
                Console.WriteLine("Generic consructor: " + type);
            }
        }

        public static void GenericMethod<t>(t type)
        {
            Console.WriteLine("Generic method: " + type);
        }
        


        public static void Dictionary()
        {
            Dictionary<int, string> dictionary = new Dictionary<int, string>();
            dictionary.Add(1, "Hola");
            dictionary.Add(2, "Bonjour");
            dictionary.Add(3, "Hallo");
            dictionary.Add(4, "Ciao");

            dictionary.Remove(4);

            foreach (KeyValuePair<int, string> item in dictionary)
            {
                Console.WriteLine("Dictionary content: " + item);
            }
        }

        public static void SortedDictionary()
        {
            SortedDictionary<int, string> sorted = new SortedDictionary<int, string>();
            sorted.Add(3, "A");
            sorted.Add(2, "B");
            sorted.Add(1, "C");


            sorted.Remove(4);

            foreach (KeyValuePair<int, string> item in sorted)
            {
                Console.WriteLine("Sorted dictionary content: " + item);
            }
        }


        public static void List()
        {
            List<string> list = new List<string>();
            list.Add("ABC");
            list.Add("DEF");
            list.Add("GHI");
            list.Add("JKL");
            list.Add("MNO");
            list.Remove("MNO");

            foreach (var item in list)
            {
                Console.WriteLine("List content: " + item);
            }
        }

        public static void HashSet()
        {
            HashSet<string> hash = new HashSet<string>();
            hash.Add("Hello");
            hash.Add("Hello");
            hash.Add("Hi");

            foreach (var item in hash)
            {
                Console.WriteLine("HashSet content: " + item);
            }
        }


        public static void SortedSet()
        {
            SortedSet<string> sorted = new SortedSet<string>();
            sorted.Add("Saitama");
            sorted.Add("Kratos");
            sorted.Add("Clark");

            foreach (var item in sorted)
            {
                Console.WriteLine("Sorted list content: " + item);
            }
        }

        public static void LinkedList()
        {
            LinkedList<string> list = new LinkedList<string>();
            list.AddFirst("Jon");
            list.AddLast("Arya");

            LinkedListNode<string> node = list.Find("Arya");

            list.AddBefore(node, "Sansa");

            foreach (var item in list)
            {
                Console.WriteLine("Linked list content: " + item);
            }
        }

        public static void Stack()
        {
            Stack<string> stack = new Stack<string>();
            stack.Push("Bruce");
            stack.Push("Arthur");
            stack.Push("Barry");

            Console.WriteLine("Stack before popping :" + stack.Pop());
            Console.WriteLine("Stack after popping :" + stack.Peek());
        }

        public static void Queue()
        {
            Queue<string> queue = new Queue<string>();
            queue.Enqueue("Constantine");
            queue.Enqueue("SwampThing");
            queue.Enqueue("Lobo");

            Console.WriteLine("Queue before dequeueing :" + queue.Dequeue());
            Console.WriteLine("Queue after dequeueing :" + queue.Peek());
        }

        public static void ArrayList()
        {
            ArrayList arraylist = new ArrayList();
            arraylist.Add("hi");
            arraylist.Add(1);
            arraylist.Add('g');
            arraylist.Add(3.45642f);
            arraylist.Add(8489574499438593329);

            arraylist.Insert(2, "Inserted at index 2");

            arraylist.Remove(1);
            

            foreach (var item in arraylist)
            {
                Console.WriteLine("Arraylist content: " + item);
            }

            Console.WriteLine("Capacity of array: " + arraylist.Capacity);
            Console.WriteLine("Count of array: " + arraylist.Count);
            Console.WriteLine("Index of 'g' is: " + arraylist.IndexOf('g'));



            //  Sorting gives exception as they are all of different types
            //arraylist.Sort();
            //Console.WriteLine("After sorting, the arraylist is :");

            //foreach (var item in arraylist)
            //{
            //    Console.WriteLine(item);
            //}


            arraylist.Reverse();
            Console.WriteLine("After reversing, the arraylist is :");

            foreach (var item in arraylist)
            {
                Console.WriteLine(item);
            }


            arraylist.Clear();
            Console.WriteLine("After clearing the elements in the arraylist are: " + arraylist.Count);

        }

        public static void BitArray()
        {
            BitArray bitarray = new BitArray(5);
            bitarray.Set(0, true);
            bitarray.Set(1, true);
            bitarray.Set(2, false);
            bitarray.Set(3, true);
            bitarray.Set(4, false);


        }

        static void Main(string[] args)
        {
            //  List
            List();


            //  HashSet (list without duplicates)
            HashSet();



            //  Sorted set (HashSet in ascending order)
            SortedSet();



            //  Dictionary
            Dictionary();



            //  Sorted dictionary
            SortedDictionary();



            //  Linked list
            LinkedList();



            //  Stack
            Stack();



            //  Queue
            Queue();


            //  ArrayList
            ArrayList();


            //  Generic class
            GenericClass<int> integer = new GenericClass<int>(5);

            GenericClass<string> str = new GenericClass<string>("Ball");

            GenericClass<char> character = new GenericClass<char>('S');

            GenericClass<float> floatingpoint = new GenericClass<float>(2.4325324f);

            //  Generic method
            GenericMethod(4);
            GenericMethod("hi");
            GenericMethod('L');



            //  XML Serialisation
            Students S = new Students();
            S.ID = 1;
            S.Name = "Me";
            S.Grade = 'F';  //Converted to ASCII

            if (File.Exists(@"U:\StudentSerialise.txt"))
            {
                FileStream f = new FileStream(@"U:\StudentSerialise.txt", FileMode.Append);
                XmlSerializer ser = new XmlSerializer(typeof(Students));
                ser.Serialize(f, S);
            }
            else
            {
                FileStream f = new FileStream(@"U:\StudentSerialise.txt", FileMode.Create);
                XmlSerializer ser = new XmlSerializer(typeof(Students));
                ser.Serialize(f, S);
            }




            //  Xml Deserialisation
            //XmlSerializer deserializer = new XmlSerializer(typeof(PersonalDetails));
            //TextReader reader = new StreamReader(@"U:\SerialisingExample.txt");
            //object obj = deserializer.Deserialize(reader);
            //PersonalDetails XmlData = (PersonalDetails)obj;
            //reader.Close();

        }
    }
}
