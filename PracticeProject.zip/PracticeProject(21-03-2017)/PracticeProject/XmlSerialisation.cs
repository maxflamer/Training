﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace PracticeProject
{
    public class XmlSerialisation
    {
        public class Address
        {
            public string City { get; set; }
            public int HouseNo { get; set; }
            public string StreetName { get; set; }
        }

        [XmlRoot("Root")]
        public class PersonalDetails
        {
            [XmlElement("Name")]
            public string Name { get; set; }

            [XmlElement("Age")]
            public int Age { get; set; }

            [XmlElement("address")]
            public Address address = new Address();

            public PersonalDetails()
            {

            }

            public void SetAddress(Address a)
            {
                address.City = a.City;
                address.HouseNo = a.HouseNo;
                address.StreetName = a.StreetName;
            }

        }
    }
}
