﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace XmlSerialisation
{
    public class Program
    {
        public class Students
        {

            public int ID { get; set; }
            public string Name { get; set; }
            public char Grade { get; set; }
        }

        public class Address
        {
            public string City { get; set; }
            public int HouseNo { get; set; }
            public string StreetName { get; set; }
        }

        public class PersonalDetails
        {
            public string Name { get; set; }
            public int Age { get; set; }
            public Address address = new Address();

            public PersonalDetails()
            {

            }

            public void SetAddress(Address a)
            {
                address.City = a.City;
                address.HouseNo = a.HouseNo;
                address.StreetName = a.StreetName; 
            }

        }


        static void Main(string[] args)
        {
            Students S = new Students();
            S.ID = 1;
            S.Name = "Me";
            S.Grade = 'F';

            if (File.Exists(@"U:\StudentSerialise.txt"))
            {
                FileStream f = new FileStream(@"U:\StudentSerialise.txt", FileMode.Append);
                XmlSerializer ser = new XmlSerializer(typeof(Students));
                ser.Serialize(f, S);
            }
            else
            {
                FileStream f = new FileStream(@"U:\StudentSerialise.txt", FileMode.Create);
                XmlSerializer ser = new XmlSerializer(typeof(Students));
                ser.Serialize(f, S);
            }








            //JsonSerializer serializer = new JsonSerializer();
            //serializer.Converters.Add(new JavaScriptDateTimeConverter());
            //serializer.NullValueHandling = NullValueHandling.Ignore;

            //using (StreamWriter sw = new StreamWriter(@"c:\json.txt"))
            //using (JsonWriter writer = new JsonTextWriter(sw))
            //{
            //    serializer.Serialize(writer, product);
            //    // {"ExpiryDate":new Date(1230375600000),"Price":0}
            //}
        }
    }
}
