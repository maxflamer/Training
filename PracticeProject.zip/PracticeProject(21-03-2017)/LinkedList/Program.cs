﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinkedList
{
    class Program
    {
        static void Main(string[] args)
        {
            LinkedList<string> list = new LinkedList<string>();
            list.AddFirst("Jon");
            list.AddLast("Arya");

            LinkedListNode<string> node = list.Find("Arya");

            list.AddBefore(node, "Sansa");

            foreach (var item in list)
            {
                Console.WriteLine(item);
            }

        }
    }
}
