﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortedDictionary
{
    class Program
    {
        static void Main(string[] args)
        {
            SortedDictionary<int, string> sorted = new SortedDictionary<int, string>();
            sorted.Add(3, "A");
            sorted.Add(2, "B");
            sorted.Add(1, "C");
            

            sorted.Remove(4);

            foreach (KeyValuePair<int, string> item in sorted)
            {
                Console.WriteLine(item);
            }
        }
    }
}
