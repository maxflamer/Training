﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Threading
{
    class Program
    {
        public static void Method1()
        {
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine("Method 1 running: " + i.ToString());
                Thread.Sleep(2000);
            }
        }

        public static void Method2()
        {
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine("Method 2 running: " + i.ToString());
                Thread.Sleep(2000);
            }
        }

        public static void WorkerThread()
        {
            
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine("Worker thread running: " + i.ToString());
                Thread.Sleep(1000);
                Thread t = Thread.CurrentThread;
                Console.WriteLine("My name is " + t.Name);
            }
        }

        static void Main(string[] args)
        {
            //  Normal methods
            //Method1();
            //Method2();

            Thread thread1 = new Thread(Method1);
            Thread thread2 = new Thread(Method2);

            //thread1.Start();
            //thread2.Start();


            //  Worker thread vs Main thread
            Thread Worker = new Thread(WorkerThread);
            Worker.Name = "Garrix";
            Worker.Start();
           
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine("Main thread running: " + i.ToString());
                Thread.Sleep(1000);
                try
                {
                    Worker.Abort();
                }
                catch (Exception e)
                {

                    Console.WriteLine(e.Message);
                }
            }


        }
    }
}
