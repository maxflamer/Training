﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            Student stu;
            stu = new Student(57,"Mahmood","Hyd");
            stu.Display();

            
        }
    }

    class College
    {
        int collegeID;
        string collegeName;
        string collegeLocation;
        internal College(int a, string b, string c)
        {
            this.collegeID = a;
            this.collegeName = b;
            this.collegeLocation = c;
           
        }

        internal void displayC()
        {
            Console.WriteLine("College ID : " + collegeID);
            Console.WriteLine("College Name : " + collegeName);
            Console.WriteLine("College ID : " + collegeLocation);
        }
    }

    class Student:College
    {
        int studentID;
        string studentName;
        string studentAddress;
        internal Student(int A, string B, string C):base(100,"OU","Hyd")
        {
            this.studentID = A;
            this.studentName = B;
            this.studentAddress = C;
           
            
        }
        internal void Display()
        {
            Console.WriteLine("StudentID : "+ studentID);
            Console.WriteLine("Student Name : "+ studentName);
            Console.WriteLine("Student Address : " + studentAddress);
            base.displayC();
        }
    }
}
