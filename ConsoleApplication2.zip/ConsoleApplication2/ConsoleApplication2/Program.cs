﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] fruits = { "Apple",null, "Orange" };


            try
            {
                for (int i = 0; i <= fruits.Length; i++)
                {
                    Console.WriteLine(fruits[i]);
                    //if (fruits[i]== null)
                    //{
                    //    throw (new ArgumentNullException());
                    //}
                }
                            }
            catch (IndexOutOfRangeException ee)
            {

                Console.WriteLine(ee.Message);
            }

            catch (ArgumentNullException ee)
            {

                Console.WriteLine(ee.Message);
            }
            finally
            {
                Console.WriteLine("\nErrors spotted\n");
            }

            int[] numbers = {1,2,3,4,5 };

            //for (int i = 0; i < 5; i++)
            //{
            //    numbers[i] = int.Parse(Console.ReadLine());
            //}
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine(numbers[i]); 
            }
            int sum = numbers.Sum();

            Console.WriteLine(sum);

            string[,] stringArray = new String[3, 3];
            stringArray[0, 0] = "A";
            stringArray[0, 1] = "B";
            stringArray[0, 2] = "C";

            stringArray[1, 0] = "D";
            stringArray[1, 1] = "E";
            stringArray[1, 2] = "F";

            stringArray[2, 0] = "G";
            stringArray[2, 1] = "H";
            stringArray[2, 2] = "I";

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.WriteLine(stringArray[i,j]);
                }
            }

            var fruity = new List<string>();
            fruity.Add("Strawberry");
            fruity.Add("Pineapply");
            fruity.Add("Cherry");

            foreach (var item in fruity)
            {
                Console.WriteLine("\n"+item);
            }
            fruity.Sort();
            foreach (var item in fruity)
            {
                Console.WriteLine("\n"+ item);
            }

            check(fruity);

            var capital = new Dictionary<string, int>();
            capital.Add("London", 1);
            capital.Add("Kingston", 2);
            capital.Add("Rome", 3);

            var keys = capital.Keys;
            string[] keyArray = keys.ToArray();
            Array.Sort(keyArray);
            foreach (var key in keys)
            {
                Console.WriteLine(key + ":" + capital[key]);
            }
            
          

            //Console.WriteLine("\nNumber of items\n" + keys + "\n");
            //Console.WriteLine(keys);

            int value;
            if (capital.TryGetValue("Rome", out value))
            {
                Console.WriteLine(value);
            }

        }

        static void check(List<string>items)
        {
            string checkCherry = items.Contains("Cherry", StringComparer.OrdinalIgnoreCase) ? "\nCherry is a berry\n" : "\nYou dummy\n";
            Console.WriteLine(checkCherry);
        }


    }
}
