﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace CollectionToXml
{

    public class FundsDistribution
    {
        public int Id { get; set; }

        public int UserId { get; set; }

        public string DistributionId { get; set; }

        public string DistributionType { get; set; }

        public string CompanyName { get; set; }

        public string DefaultAccountKey { get; set; }

        public DateTime LastDistributionDate { get; set; }

        public float LastDistibutionAmount { get; set; }

        public bool IsDeleted { get; set; }

        public string DefaultAccountDescription { get; set; }
    }

    public class Program
    {
        public static string FromBytes(byte[] chars)
        {
            UTF8Encoding encoding = new UTF8Encoding();
            string content = encoding.GetString(chars);

            // Return the string.
            return content;
        }

        static void Main(string[] args)
        {
            Collection<FundsDistribution> fundsdistributionHistoryModels = new Collection<FundsDistribution>()
            {
                new FundsDistribution() { Id = 1, DistributionId = "00012", UserId = 9, DistributionType = "A", CompanyName = "ACME", DefaultAccountKey = "nil", LastDistributionDate = DateTime.Now, LastDistibutionAmount = 16551303, IsDeleted = false, DefaultAccountDescription = "Account description 1" },
                new FundsDistribution() { Id = 2, DistributionId = "00013", UserId = 8, DistributionType = "B", CompanyName = "DOLI", DefaultAccountKey = "nil", LastDistributionDate = DateTime.Now, LastDistibutionAmount = 16320237, IsDeleted = false, DefaultAccountDescription = "Account description 2" },
                new FundsDistribution() { Id = 3, DistributionId = "00014", UserId = 7, DistributionType = "C", CompanyName = "BIBA", DefaultAccountKey = "nil", LastDistributionDate = DateTime.Now, LastDistibutionAmount = 35406586, IsDeleted = false, DefaultAccountDescription = "Account description 3" },
                new FundsDistribution() { Id = 4, DistributionId = "00015", UserId = 6, DistributionType = "D", CompanyName = "XONO", DefaultAccountKey = "nil", LastDistributionDate = DateTime.Now, LastDistibutionAmount = 78404665, IsDeleted = false, DefaultAccountDescription = "Account description 4" },
                new FundsDistribution() { Id = 5, DistributionId = "00016", UserId = 5, DistributionType = "E", CompanyName = "JACK", DefaultAccountKey = "nil", LastDistributionDate = DateTime.Now, LastDistibutionAmount = 36547047, IsDeleted = false, DefaultAccountDescription = "Account description 5" }
            };

            string xml = null;
            MemoryStream memstream = new MemoryStream();
            XmlSerializer xmls = new XmlSerializer(typeof(Collection<FundsDistribution>));
            XmlTextWriter xmltextwriter = new XmlTextWriter(memstream, Encoding.UTF8);

            // Serialize object.
            xmls.Serialize(xmltextwriter, fundsdistributionHistoryModels);
            memstream = (MemoryStream)xmltextwriter.BaseStream;
            xml = FromBytes(memstream.ToArray());

            
        }
    }
}
