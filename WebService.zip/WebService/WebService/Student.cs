﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebService
{
    public class Student
    {
        public string name { get; set; }
        public int age { get; set; }
        public string dept { get; set; }

        public Student ()
        {

        }

        public Student (string a,int b,string c)
        {
            this.name = a;
            this.age = b;
            this.dept = c;
        }
    }
}