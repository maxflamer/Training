﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
//using System.Xml;
using System.Xml.Serialization;
using System.IO;
using System.Xml.Linq;

namespace WebService
{
    /// <summary>
    /// Summary description for WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {

        //[WebMethod]
        //public List<obj> submitdata(string a, int b, string c)
        //{
        //    List<obj> list = new List<obj>();
        //    DataSet ds = new DataSet();
        //    list.Add(new obj("Me", 21, "ECE"));
        //    list.Add(new obj("You", 30, "CSE"));
        //    list.Add(new obj("He", 11, "EEE"));
        //    list.Add(new obj("She", 23, "BME"));
        //    list.Add(new obj(a,b,c));

        //    //ds.ReadXml();

        //    return list;

        //}

        [WebMethod]
        public void send_data(string Name, int Age, string Dept)
        {
            List<Student> list = new List<Student>();
            list.Add(new Student(Name, Age, Dept));

            XElement elem;
            if (!File.Exists(Server.MapPath(@"Sample1.xml")))
            {
                elem = new XElement("Students");
                elem.Save(Server.MapPath(@"Sample1.xml"));
            }



            XElement st = XElement.Load(Server.MapPath(@"Sample1.xml"));
            XElement student =new XElement("Student",
             new XElement("Name", Name),
           new XElement("Age", Age),
           new XElement("Department", Dept)
            );
            st.Add(student);
            st.Save(Server.MapPath(@"Sample1.xml"));



        }



        //    Old code
        //    ****************************************************************************************************
        //    XmlDocument xmlDoc = new XmlDocument();

            //    if (!File.Exists(Server.MapPath(@"Sample.xml"))) 
            //    {
            //        XmlNode root = xmlDoc.CreateElement("Students");
            //        xmlDoc.AppendChild(root);
            //        xmlDoc.Save(Server.MapPath(@"Sample.xml"));

            //        //XElement xml =new XElement("students");
            //        //xmlDoc.AppendChild(xml);
            //        //xml.Save(Server.MapPath(@"Sample.xml"));


            //        //abc.Add(new XElement ("Students" ), new XElement ("Name",Name), new XElement("Age",Age),new XElement("Department",Dept) );
            //        //abc.Save(Server.MapPath("Sample.xml"));
            //    }

            //    //XElement xml1 = XElement.Load(Server.MapPath(@"Sample.xml"));
            //    //xml1.Save(Server.MapPath(@"Sample.xml"));
            //    //string path = "Server.MapPath(@'Sample.xml')";
            //    xmlDoc.Load(Server.MapPath("Sample.xml"));


            //    //old.Save(Server.MapPath(@"Sample.xml"));

            //    XmlNode rootNode = xmlDoc.CreateElement("Student");
            //        xmlDoc.AppendChild(rootNode);

            //        XmlNode userNode = xmlDoc.CreateElement("Name");
            //        userNode.InnerText = Name;
            //        rootNode.AppendChild(userNode);

            //        XmlNode userNode2 = xmlDoc.CreateElement("Age");
            //        userNode2.InnerText = Age.ToString();
            //        rootNode.AppendChild(userNode2);

            //        XmlNode userNode3 = xmlDoc.CreateElement("Dept");
            //        userNode3.InnerText = Dept;
            //        rootNode.AppendChild(userNode3);

            //        xmlDoc.Save(Server.MapPath("Sample.xml"));


            //    //Writing to XML earlier
            //    //XmlSerializer serialiser = new XmlSerializer(typeof(List<Student>));
            //    //TextWriter FileStream = new StreamWriter(@"U:\WebService.xml");
            //    //serialiser.Serialize(FileStream, list);
            //    //FileStream.Close();
            //}
            //************************************************************************************************************************


        [WebMethod]
        public DataSet get_data()
        {
            DataSet ds = new DataSet();
            ds.ReadXml(Server.MapPath("Sample.xml"));
            return ds;
        }


        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }

        [WebMethod]
        public string Function(string a,string b)
        {
            return a + " " + b;
        }

        [WebMethod]
        public double Addition(int a, int b)
        {
            return a + b;
        }

        [WebMethod]
        public double Subtraction(int a, int b)
        {
            return a - b;
        }

        [WebMethod]
        public double Multiplication(int a, int b)
        {
            return a * b;
        }

        [WebMethod]
        public double Division(int a, int b)
        {
            return a / b;
        }


        //public class obj
        //    {

        //    obj () {

        //    }

        //    public string NAME { get; set; }
        //    public int AGE { get; set; }
        //    public string DEPT { get; set; }

         

        //    public obj(string a, int b, string c)
        //    {
        //        this.NAME = a;
        //        this.AGE = b;
        //        this.DEPT = c;
        //    }
        //}
    }
      


    }


