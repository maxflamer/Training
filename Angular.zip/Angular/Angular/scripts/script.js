﻿/// <reference path="angular.min.js" />


var myApp = angular.module("mymodule", []);


//var anotherController = function ($scope) {              //defining a controller
//    var images = {
//        name: "Scene",
//        img: "~/Img/001.jpg"
//    };
//    $scope.image = images;
//};

//myApp.controller("anotherController", anotherController);     //register controller to the module


// OR you can do it in-line

myApp.controller("myController", function ($scope) {
    var employee = {
        firstName: "Mahmood",
        lastName: "Khan",
        gender: "Male"
    }
    $scope.employee = employee;
    console.log(employee);
});



//can be done by method chaining as well
//var myApp = angular.module("mymodule", []).controller("myController", function ($scope) {
//    var employee = {
//        firstName: "Mahmood",
//        lastName: "Khan",
//        gender: "Male"
//    }
//    $scope.employee = employee;
//    console.log(employee);
//});


myApp.controller("anotherController", function ($scope) {
    var images = {
        name: "Scene",
        img: "/Img/001.jpg"
    };
    $scope.image = images;
});