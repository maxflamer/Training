﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WebServiceApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //ServiceReference1.WebService1SoapClient myService = new ServiceReference1.WebService1SoapClient();
            //string message = myService.HelloWorld();
            //labelOutput.Content = message;
            labelOutput.Content = "";
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            string value1 = textBox1.Text;
            string value2 = textBox2.Text;
              
            ServiceReference1.WebService1SoapClient myService = new ServiceReference1.WebService1SoapClient();
            string result = myService.Function(value1, value2);
            labelOutput.Content = result;


        }

        private void buttonAdd_Click(object sender, RoutedEventArgs e)
        {
            string value1 = textBox1.Text;
            string value2 = textBox2.Text;
           
            int number1 = int.Parse(value1);
            int number2 = int.Parse(value2);
            ServiceReference1.WebService1SoapClient myService = new ServiceReference1.WebService1SoapClient();
            double result = myService.Addition(number1,number2);
            labelOutput.Content = result.ToString();
        }

        private void buttonSub_Click(object sender, RoutedEventArgs e)
        {
            string value1 = textBox1.Text;
            string value2 = textBox2.Text;
            int number1 = int.Parse(value1);
            int number2 = int.Parse(value2);
            ServiceReference1.WebService1SoapClient myService = new ServiceReference1.WebService1SoapClient();
            double result = myService.Subtraction(number1, number2);
            labelOutput.Content = result.ToString();
        }

        private void buttonMul_Click(object sender, RoutedEventArgs e)
        {
            string value1 = textBox1.Text;
            string value2 = textBox2.Text;
            int number1 = int.Parse(value1);
            int number2 = int.Parse(value2);
            ServiceReference1.WebService1SoapClient myService = new ServiceReference1.WebService1SoapClient();
            double result = myService.Multiplication(number1, number2);
            labelOutput.Content = result.ToString();
        }

        private void buttonDiv_Click(object sender, RoutedEventArgs e)
        {
            string value1 = textBox1.Text;
            string value2 = textBox2.Text;
            int number1 = int.Parse(value1);
            int number2 = int.Parse(value2);
            ServiceReference1.WebService1SoapClient myService = new ServiceReference1.WebService1SoapClient();
            double result = myService.Division(number1, number2);
            labelOutput.Content = result.ToString();
        }
    }
}
