﻿using System;
using System.Collections.Generic;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            labelAverage.Visible = false;
            labelRemarks.Visible = false;
            labelAverage_result.Visible = false;
            labelRemarks_result.Visible = false;
            labelAverage_result.Text = "";
            labelRemarks_result.Text = "";
            labelMessage.Text = "";

        }


        protected void button_register_Click(object sender, EventArgs e)
        {
            
            int Id = int.Parse(textbox_studid.Text);
            string Name = textbox_studname.Text;
            string Dept = textbox_stud_deptname.Text;
            int Maths = int.Parse(textbox_mathsmarks.Text);
            int Physics = int.Parse(textbox_physicsmarks.Text);
            int Chemistry = int.Parse(textbox_chemistrysmarks.Text);
            double Average = (Maths + Physics + Chemistry) / 3;
            string Remarks;
            //labelAverage.Visible = true;
            //labelRemarks.Visible = true;
            //labelAverage_result.Visible = true;
            //labelRemarks_result.Visible = true;
            if (Average>=50)
            {
                Remarks = "Passed";
                //if (labelRemarks_result.ForeColor != System.Drawing.Color.Green)
                //{
                //    labelRemarks_result.ForeColor = System.Drawing.Color.Green;
                //}
                //else
                //{
                //    labelRemarks_result.ForeColor = new System.Drawing.Color();
                //}
            }
            else
            {
                Remarks = "Failed";
                //if (labelRemarks_result.ForeColor != System.Drawing.Color.Red)
                //{
                //    labelRemarks_result.ForeColor = System.Drawing.Color.Red;
                //}
                //else
                //{
                //    labelRemarks_result.ForeColor = new System.Drawing.Color();
                //}
            }

            labelMessage.Text = "Registered Successfully";
            //var f = new Student();
            //var blank = f.read((Server.MapPath("sample2.xml")));


            //var s = new Student(Id,Name,Dept,Maths,Physics,Chemistry,Average,Remarks);
            List<Student> s = new List<Student>();
            s.Add(new Student(Id, Name, Dept, Maths, Physics, Chemistry, Average, Remarks)); 
            //var student_list = new List<Student>();
            //student_list.Add(f);
            //student_list.Add(s);
            labelAverage_result.Text = Average.ToString();
            labelRemarks_result.Text = Remarks;
            XmlSerializer serialize = new XmlSerializer(typeof(List<Student>));
            TextWriter tw = new StreamWriter(@"C:\Users\mkhan\Documents\Visual Studio 2015\Projects\WebApplication1\WebApplication1\sample2.xml");
            
serialize.Serialize(tw, s);
            tw.Close();
            //FileStream file = File.Create(Server.MapPath("sample2.xml"));
            //using (var file = File.Open(Server.MapPath(@"sample2.xml"), FileMode.OpenOrCreate))
            //    serialize.Serialize(file, s);
            
            //Session["details"]=
            
        }

        protected void button_view_Click(object sender, EventArgs e)
        {
            Response.Redirect("Search_Page.aspx");
        }

        //protected void button_register_Click1(object sender, EventArgs e)
        //{

        //}
    }

   

        //protected void button_check_Click(object sender, EventArgs e)
        //{
        //    Session["id"] = textbox_chemistrysmarks.Text;
            
        //}
    }
