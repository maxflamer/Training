﻿using System.Collections.Generic;

namespace WebApplication1
{
    internal class Lst<T> : List<Student>
    {
    }
}