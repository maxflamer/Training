﻿using System;
using System.Collections.Generic;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public class Student
    {
        public int id { get; set; }
        public string name { get; set; }
        public string dept { get; set; }
        public int maths { get; set; }
        public int physics { get; set; }
        public int chemistry { get; set; }
        public double average { get; set; }
        public string remarks { get; set; }
        

      public Student()
        {

        }

        public Student(int Id,string Name,string Dept,int Maths,int Physics,int Chemistry,double Average,string Remarks)
        {
            id = Id;
            name = Name;
            dept = Dept;
            maths = Maths;
            physics = Physics;
            chemistry = Chemistry;
            average = Average;
            remarks = Remarks;
        }

        public List<Student> read (string path)
        {
            XmlSerializer serialise = new XmlSerializer(typeof(List<Student>));
           
            
            StreamReader file = new StreamReader(path);
            List<Student> ob;
            ob = (List<Student>)serialise.Deserialize(file);


            
            file.Close();
            return ob;
        }
    }
}