﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class Search_Page : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Session["id"] =;
        }

        protected void button_check_Click(object sender, EventArgs e)
        {
            string NAME = textbox_search.Text;
            var slist = new List<Student>();
            var s = new Student();
            var blank = s.read((Server.MapPath("sample2.xml")));

            IEnumerable<Student> someQuery =
                from someVariable in blank
                where someVariable.name == NAME
                select someVariable;

            foreach (var item in someQuery)
            {
               
                string r = "Student ID: " + item.id + "<BR/>" + "Student name: " + item.name + "<BR/>" + "Department name: " + item.dept + "<BR/>" + "Maths marks: " + item.maths + "<BR/>" + "Physics marks: " + item.physics + "<BR/>" + "Chemistry marks: " + item.chemistry + "<BR/>" + "Average marks: " + item.average + "<BR/>" + "Remarks: " + item.remarks;
                if (item.average >= 50)
                {
                    label_results.Style.Add("color", "mediumseagreen;");
                }
                else
                {
                    label_results.Style.Add("color", "red;");
                }
                label_results.Text = r;

            }

        }

        protected void button_back_Click(object sender, EventArgs e)
        {
            Response.Redirect("Main_Page.aspx");
        }
    }
}