﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrySerialisation
{
    class Program
    {
        static void Main(string[] args)
        {

            //a = int.Parse(Console.ReadLine());

            //for (j = 0; j < 2; j++)
            //{
            //    for (i = 0; i < 4; i++)
            //    {
            //        Console.Write(a + " ");
            //    }
            //    Console.Write("\n");
            //    for (i = 0; i < 4; i++)
            //    {
            //        Console.Write(a);

            //    }
            //    Console.Write("\n");
            //}

            //Console.WriteLine("");

            //for (i = 0; i < 3; i++)
            //{
            //    Console.Write(a);
            //}

            //Console.WriteLine("");

            //for (j = 0; j < 2; j++)
            //{
            //    for (i = 0; i < 2; i++)
            //    {
            //        Console.Write(a + " ");
            //    }
            //    Console.Write("\n");
            //}
            //for (i = 0; i < 3; i++)
            //{
            //    Console.Write(a);
            //}

            //Console.WriteLine("");
            //string s = "Something";

            //Console.WriteLine(s.Remove(6,2));


            //int a = int.Parse(Console.ReadLine());
            //int b = int.Parse(Console.ReadLine());
            //int c = int.Parse(Console.ReadLine());
            //double d = ((b * b) - (4 * a * c)) / (2 * a);

            //Console.WriteLine(d);

            //for (int i = 0; i < 4; i++)
            //{
            //    for (int j = 0; j <=i; j++)
            //    {
            //        Console.Write(i+1);
            //    }
            //    Console.WriteLine("");
            //}

            //int k = 1;
            //for (int i = 0; i < 4; i++)
            //{
            //    for (int j = 0; j <=i; j++)
            //    {
            //        Console.Write(k + " ");
            //        k++;
            //    }
            //    Console.WriteLine("");
            //}   

           
        }
    }

   
}
