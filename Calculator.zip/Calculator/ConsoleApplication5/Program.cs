﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication5
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("\n\nEnter two numbers\n");
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
                Console.WriteLine("\n\nEnter an operation:\n1. Addition (+)\n2. Subtraction (-)\n3. Multiplication (*)\n4. Divison (/)\n5. Modulus (%)\n");
                string o = Console.ReadLine();
                o.ToLower();
                var op = new Operation(a, b, o);
                op.display();
                Console.WriteLine("\n\nAnother Operation? Y/N");
                char option = Console.ReadKey().KeyChar;
                if (option == 78 || option == 110)
                {
                    Console.WriteLine("Thank you");
                    break;
                }
                else
                {
                    continue;
                }
            }
           

        }
    }
    class Operation
    {
        public int One { get; set; }
        public int Two { get; set; }
        public string Three { get; set; }
        public Operation (int one, int two, string three)
        {
            this.One = one;
            this.Two = two;
            this.Three = three;
        }

        public void display ()
        {
            if (Three == "1" || Three == "addition")
            {
                int c = One + Two;
                Console.WriteLine("Sum is : " + c);
            }

            else if (Three == "2" || Three == "subtraction")
            {
                int c = One - Two;
                Console.WriteLine("Difference is : " + c);
            }

            else if (Three == "3" || Three == "multiplication")
            {
                int c = One * Two;
                Console.WriteLine("Product is : " + c);
            }
            else if (Three == "4" || Three == "division")
            {
                double c = One / Two;
                Console.WriteLine("Quotient is : " + c);
            }
            else if (Three == "5" || Three == "modulus")
            {
                int c = One % Two;
                Console.WriteLine("Modulus is : " + c);
            }

            else
            {
                Console.WriteLine("Enter a valid input, pal");
            }
        }
        
    }
}
