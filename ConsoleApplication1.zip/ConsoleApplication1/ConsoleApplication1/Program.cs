﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your name: \n");
            string name=Console.ReadLine();
            Console.WriteLine("Welcome to Visual Studio, " + name);
            Console.WriteLine("What is your age?\n");
            int age = int.Parse(Console.ReadLine());
            Console.WriteLine("Your age is " + age + ", you were born in 1995\n");


            int i,j;
            for (i)

        }
    }
}
