﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PriceList
{
    public partial class PriceLList : System.Web.UI.Page
    {
        static int one = 1;
        static int two = 1;
        static int three = 1;
        int price1 = 15;
        int price2 = 10;
        int price3 = 5;
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void imageapple_Click(object sender, ImageClickEventArgs e)
        {
            
            TextBox1.Text = one.ToString();
            one++;
        }

        protected void imageorange_Click(object sender, ImageClickEventArgs e)
        {
            TextBox2.Text = two.ToString();
            two++;
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            TextBox3.Text = three.ToString();
            three++;
        }

        protected void buttontotal_Click(object sender, EventArgs e)
        {
            int val1 = int.Parse(TextBox1.Text);
            int val2 = int.Parse(TextBox2.Text);
            int val3 = int.Parse(TextBox3.Text);


            int result = (val1 * price1) + (val2 * price2) + (val3 * price3);
            labelresult.Text = result.ToString();

        }
    }
}