﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;

namespace Task
{
    class Program
    {
        static void Main(string[] args)
        {
            var slist = new List<Student>();

            while (true)
            {
                Console.WriteLine("");
                Console.WriteLine("Enter the ID");
                int id = int.Parse(Console.ReadLine());
                Console.WriteLine("\nEnter the name");
                string name = Console.ReadLine();
                Console.WriteLine("\nEnter the department");
                string department = Console.ReadLine();
                Console.WriteLine("\nEnter the marks in Maths");
                int maths = int.Parse(Console.ReadLine());
                Console.WriteLine("\nEnter the marks in Physics");
                int physics = int.Parse(Console.ReadLine());
                Console.WriteLine("\nEnter the marks in Chemistry");
                int chemistry = int.Parse(Console.ReadLine());
                double average = ((maths + physics + chemistry) / 3);
                Console.WriteLine("Average: " + average);
                string remark;
                if (average >= 50)
                {
                     remark = "Passed! :)";
                }
                else
                {
                   remark = "Failed :(";
                }


                Console.WriteLine("\n\nDo you want to continue? Y/N");
                char option = Console.ReadKey().KeyChar;
                var s = new Student(id, name, department, maths, physics, chemistry, average, remark);
                slist.Add(new Student(id, name, department, maths, physics, chemistry, average, remark));

                XmlSerializer serializer = new XmlSerializer(typeof(List<Student>));
                TextWriter tw = new StreamWriter(@"sample.xml");
                serializer.Serialize(tw, slist);
                tw.Close();

                Console.WriteLine("");

               if (option == 78 || option == 110)
                {
                    
                }
               else
                {
                    continue;
                }
            
            while (true)
                {
                    Console.WriteLine("\n\nDo you want to see the results? Y/N");
                    char option2 = Console.ReadKey().KeyChar;
                    Console.WriteLine("");

                    if (option2 == 78 || option2 == 110)
                    {
                        Console.WriteLine("Thank you\n");
                        break;
                    }
                    else
                    {
                        Console.WriteLine("\nName of the student you'd like to view:\n");
                        string namee = Console.ReadLine();
                        var blank = s.read(@"sample.xml") ;
                        IEnumerable<Student> someQuery =
                            from stu in blank
                            where stu.NAME == namee
                            select stu;

                        foreach (var item in someQuery)
                        {
                            Console.WriteLine("\nStudent ID: " + item.ID);
                            Console.WriteLine("Student name: " + item.NAME);
                            Console.WriteLine("Department name: " + item.DEPARTMENT);
                            Console.WriteLine("Maths marks: " + item.MATHS);
                            Console.WriteLine("Physics marks: " + item.PHYSICS);
                            Console.WriteLine("Chemistry marks: " + item.CHEMISTRY);
                            Console.WriteLine("Average marks: " + item.AVERAGE);
                            Console.WriteLine("Remarks: " + item.REMARK);
                        }
                        continue;
                    }
                }
                break; 
        }
        }

    }

    public class Student
    {
        public Student()
        {

        }
        public Student(int id,string name,string department,int maths,int physics,int chemistry,double average,string remark)
        {
            ID = id;
            NAME = name;
            DEPARTMENT = department;
            MATHS = maths;
            PHYSICS = physics;
            CHEMISTRY = chemistry;
            AVERAGE = average;
            REMARK = remark; 
        }

        public int ID { get; set; }
        public string NAME { get; set; }
        public string DEPARTMENT { get; set; }
        public int MATHS { get; set; }
        public int PHYSICS { get; set; }
        public int CHEMISTRY { get; set; }
        public double AVERAGE { get; set; }
        public string REMARK { get; set; }

        public List<Student> read(string path)
        {
            XmlSerializer serialise = new XmlSerializer(typeof(List<Student>));
            TextReader tr = new StreamReader(path);
            List<Student> obj;
            
           obj =(List<Student>) serialise.Deserialize(tr);
            return obj;

        }

    }
}